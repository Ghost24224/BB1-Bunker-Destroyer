import tkinter as tk
import math
import random
import time
import winsound

class TacticalRadarDeepTone:
    def __init__(self):
        self.root = tk.Tk()
        self.root.title("EW INTERFACE - DEEP TONE RWR - V7.5")
        self.root.geometry("1100x800")
        self.canvas = tk.Canvas(self.root, width=1100, height=800, bg="black", highlightthickness=0)
        self.canvas.pack()

        self.cx, self.cy = 400, 400
        self.r = 350 
        self.angle = 0
        self.start_time = time.time()
        self.stage = 1
        
        self.decoys = [] 
        self.target_list_ids = []
        self.speed_mult = 0.4 
        self.accel = 1.0 
        
        self.setup_ui()
        self.update()
        self.root.mainloop()

    def setup_ui(self):
        for i in range(1, 6):
            self.canvas.create_oval(self.cx-(i*70), self.cy-(i*70), self.cx+(i*70), self.cy+(i*70), outline="#002200")
        
        self.canvas.create_rectangle(800, 0, 1100, 800, fill="#020202", outline="#00FF00")
        self.canvas.create_text(950, 30, text="EW THREAT DISPLAY", fill="#00FF00", font=("Consolas", 12, "bold"))
        self.list_container = self.canvas.create_text(810, 60, anchor="nw", text="", fill="#00FF00", font=("Consolas", 8))

        self.px, self.py = 50, 400
        self.plane = self.canvas.create_oval(0,0,0,0, fill="white", tags="unit")
        self.plane_tag = self.canvas.create_text(0,0, text="TGT: B-2 STEALTH", fill="red", font=("Consolas", 8, "bold"))

        self.bb_x, self.bb_y = 0, 0
        self.bb = self.canvas.create_oval(0,0,0,0, fill="yellow", state="hidden")
        self.bb_tag = self.canvas.create_text(0,0, text="", fill="yellow", font=("Consolas", 9, "bold"))

    def play_deep_glitch_sound(self, intensity):
        # Sesler kalınlaştırıldı (800Hz ve 500Hz seviyesine çekildi)
        for _ in range(2):
            winsound.Beep(800, 120)  # Kalın üst ton
            winsound.Beep(500, 120)  # Daha kalın alt ton
            
            if random.random() < intensity:
                # Glitch sesleri de daha baslı 'hrrt' tonunda
                winsound.Beep(random.randint(80, 200), 50) 
            time.sleep(0.02)

    def is_outside(self, x, y):
        return math.sqrt((x - self.cx)**2 + (y - self.cy)**2) > self.r

    def update(self):
        elapsed = time.time() - self.start_time
        
        self.angle += 0.05 
        lx = self.cx + self.r * math.cos(self.angle)
        ly = self.cy + self.r * math.sin(self.angle)
        self.canvas.create_line(self.cx, self.cy, lx, ly, fill="#00FF00", width=2, tags="scan")
        self.canvas.after(30, lambda: self.canvas.delete("scan"))

        if self.stage == 1:
            self.px += 2.5 * self.speed_mult
            self.canvas.coords(self.plane, self.px-6, self.py-6, self.px+6, self.py+6)
            self.canvas.coords(self.plane_tag, self.px+60, self.py-20)
            if elapsed > 6: 
                self.stage = 2
                self.bb_x, self.bb_y = self.px, self.py
                self.canvas.itemconfig(self.bb, state="normal")

        elif self.stage == 2:
            self.bb_x += 2.5 * self.speed_mult
            self.bb_y -= 0.3 * self.speed_mult
            self.canvas.coords(self.bb, self.bb_x-4, self.bb_y-4, self.bb_x+4, self.bb_y+4)
            self.canvas.itemconfig(self.bb_tag, text="ID: ARDBBRDRLEXPLM")
            self.canvas.coords(self.bb_tag, self.bb_x+60, self.bb_y+15)

            self.accel += 0.02
            self.px -= 1.8 * self.speed_mult * self.accel
            self.py -= 3.5 * self.speed_mult * self.accel
            self.canvas.coords(self.plane, self.px-6, self.py-6, self.px+6, self.py+6)
            self.canvas.coords(self.plane_tag, self.px+60, self.py-20)
            
            if self.is_outside(self.px, self.py):
                self.canvas.delete(self.plane); self.canvas.delete(self.plane_tag)
            if elapsed > 13: self.stage = 3

        elif self.stage == 3:
            if len(self.decoys) < 60:
                for _ in range(2):
                    vx, vy = random.uniform(-0.8, 0.8), random.uniform(-0.8, 0.8)
                    dot = self.canvas.create_oval(self.bb_x-2, self.bb_y-2, self.bb_x+2, self.bb_y+2, fill="#00CC00")
                    txt = self.canvas.create_text(self.bb_x+15, self.bb_y+8, text=f"S-{random.randint(100,999)}", fill="#008800", font=("Consolas", 6))
                    self.decoys.append({'dot': dot, 'txt': txt, 'x': self.bb_x, 'y': self.bb_y, 'vx': vx, 'vy': vy})
            
            for d in self.decoys:
                d['x'] += d['vx']; d['y'] += d['vy']
                self.canvas.coords(d['dot'], d['x']-2, d['y']-2, d['x']+2, d['y']+2)
                self.canvas.coords(d['txt'], d['x']+15, d['y']+8)

            self.bb_x += 2.0 * self.speed_mult
            self.canvas.coords(self.bb, self.bb_x-4, self.bb_y-4, self.bb_x+4, self.bb_y+4)
            self.canvas.coords(self.bb_tag, self.bb_x+60, self.bb_y+15)
            
            if elapsed > 21: self.stage = 4

        elif self.stage == 4:
            self.canvas.itemconfig(self.bb, state="hidden")
            self.canvas.itemconfig(self.bb_tag, text="")
            distort = (elapsed - 21) / 3.0
            self.play_deep_glitch_sound(distort) 
            if elapsed > 24: self.stage = 5

        elif self.stage == 5:
            self.canvas.delete("all")
            self.canvas.config(bg="#200000")
            winsound.Beep(180, 1200) # Final çöküş bas sesi
            msg = "!!! SYSTEM TOTAL FAILURE !!!\nSIGNAL JAMMED - ANTENNA OFFLINE\nELECTRONIC ATTACK SUCCESSFUL"
            self.canvas.create_text(550, 400, text=msg, fill="white", font=("Consolas", 24, "bold"), justify="center")
            if elapsed > 30: self.root.destroy()

        self.root.after(30, self.update)

if __name__ == "__main__":
    TacticalRadarDeepTone()